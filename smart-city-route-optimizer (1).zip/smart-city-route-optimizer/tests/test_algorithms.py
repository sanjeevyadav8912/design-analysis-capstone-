import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import pytest
from graph import CityGraph, generate_random_city
from algorithms import dijkstra, bellman_ford, reconstruct_path


def small():
    g = CityGraph()
    for u, v, w in [("A", "B", 4), ("A", "C", 1), ("C", "B", 2), ("B", "D", 5)]:
        g.add_road(u, v, w)
    return g


def test_known_shortest_path():
    d, p = dijkstra(small(), "A")
    assert d["D"] == 8
    assert reconstruct_path(p, "A", "D") == ["A", "C", "B", "D"]


def test_algorithms_agree_on_random_graphs():
    for seed in range(5):
        g = generate_random_city(150, seed=seed)
        assert dijkstra(g, 0)[0] == bellman_ford(g, 0)[0]


def test_unreachable_is_infinite():
    g = small(); g.add_location("Z")
    assert dijkstra(g, "A")[0]["Z"] == float("inf")


def test_bellman_ford_negative_edge_and_cycle():
    g = CityGraph(directed=True)
    g.add_road("A", "B", 4); g.add_road("B", "C", -2)
    assert bellman_ford(g, "A")[0]["C"] == 2
    g.add_road("C", "B", 1)  # B->C->B = -1 cycle
    with pytest.raises(ValueError):
        bellman_ford(g, "A")


def test_dijkstra_rejects_negative_weights():
    g = CityGraph(directed=True); g.add_road("A", "B", -1)
    with pytest.raises(ValueError):
        dijkstra(g, "A")
