"""Compare Dijkstra vs Bellman-Ford across graph sizes."""
import csv
import time
from algorithms import dijkstra, bellman_ford
from graph import generate_random_city


def time_it(fn, graph, source, repeats=3):
    best = float("inf")
    for _ in range(repeats):
        t = time.perf_counter()
        fn(graph, source)
        best = min(best, time.perf_counter() - t)
    return best * 1000  # ms


def run(sizes=(50, 100, 200, 400, 800, 1600), out="results/benchmark.csv"):
    rows = []
    print(f"{'V':>6} {'E':>8} {'Dijkstra(ms)':>14} {'BellmanFord(ms)':>16} {'Slower by':>10}")
    for n in sizes:
        g = generate_random_city(n)
        d = time_it(dijkstra, g, 0)
        b = time_it(bellman_ford, g, 0)
        rows.append((n, g.num_edges, round(d, 3), round(b, 3)))
        print(f"{n:>6} {g.num_edges:>8} {d:>14.3f} {b:>16.3f} {b/d:>9.1f}x")
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["vertices", "edges", "dijkstra_ms", "bellman_ford_ms"])
        w.writerows(rows)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.plot([r[0] for r in rows], [r[2] for r in rows], "o-", label="Dijkstra")
        plt.plot([r[0] for r in rows], [r[3] for r in rows], "s-", label="Bellman-Ford")
        plt.xlabel("Number of locations (V)"); plt.ylabel("Time (ms)")
        plt.title("Shortest path runtime comparison"); plt.legend(); plt.grid(True)
        plt.savefig(out.replace(".csv", ".png"), dpi=150)
        print("Saved plot")
    except ImportError:
        print("matplotlib not installed - skipped plot (CSV still saved)")
    return rows


if __name__ == "__main__":
    run()
