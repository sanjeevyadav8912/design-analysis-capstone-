"""Demo: a small named city + CLI route finder."""
import argparse
from graph import CityGraph
from algorithms import dijkstra, bellman_ford, reconstruct_path


def build_demo_city():
    g = CityGraph()
    roads = [
        ("Airport", "Central Station", 18), ("Airport", "Tech Park", 25),
        ("Central Station", "Market", 6), ("Central Station", "University", 9),
        ("Market", "Old Town", 5), ("Market", "Hospital", 8),
        ("University", "Hospital", 4), ("University", "Tech Park", 12),
        ("Old Town", "Stadium", 10), ("Hospital", "Stadium", 7),
        ("Tech Park", "Stadium", 20),
    ]
    for u, v, w in roads:
        g.add_road(u, v, w)
    return g


def main():
    g = build_demo_city()
    p = argparse.ArgumentParser(description="Smart City Route Optimizer")
    p.add_argument("--source", default="Airport")
    p.add_argument("--target", default="Stadium")
    p.add_argument("--algo", choices=["dijkstra", "bellman-ford"], default="dijkstra")
    a = p.parse_args()
    for name in (a.source, a.target):
        if name not in g.vertices:
            raise SystemExit(f"Unknown location '{name}'. Choose from: {sorted(g.vertices)}")
    fn = dijkstra if a.algo == "dijkstra" else bellman_ford
    dist, prev = fn(g, a.source)
    path = reconstruct_path(prev, a.source, a.target)
    print(f"Algorithm : {a.algo}")
    print(f"Route     : {' -> '.join(path)}")
    print(f"Total cost: {dist[a.target]} min")


if __name__ == "__main__":
    main()
