"""Graph representation: locations are vertices, roads are weighted edges."""
import random
from collections import defaultdict


class CityGraph:
    def __init__(self, directed=False):
        self.directed = directed
        self.adj = defaultdict(list)   # u -> [(v, weight)]
        self.vertices = set()

    def add_location(self, name):
        self.vertices.add(name)

    def add_road(self, u, v, weight):
        """weight = distance (km) or travel time (min)."""
        self.vertices.update((u, v))
        self.adj[u].append((v, weight))
        if not self.directed:
            self.adj[v].append((u, weight))

    def edges(self):
        for u in self.adj:
            for v, w in self.adj[u]:
                yield u, v, w

    @property
    def num_vertices(self):
        return len(self.vertices)

    @property
    def num_edges(self):
        return sum(len(n) for n in self.adj.values())


def generate_random_city(n, extra_edge_factor=3, seed=42, max_weight=50):
    """Connected random graph: a spanning chain plus random extra roads."""
    rng = random.Random(seed)
    g = CityGraph(directed=True)  # two-way roads stored as two directed edges
    for i in range(n):
        g.add_location(i)
    for i in range(n - 1):  # guarantees connectivity
        w = rng.randint(1, max_weight)
        g.add_road(i, i + 1, w)
        g.add_road(i + 1, i, w)
    for _ in range(n * extra_edge_factor):
        u, v = rng.randrange(n), rng.randrange(n)
        if u != v:
            w = rng.randint(1, max_weight)
            g.add_road(u, v, w)
            g.add_road(v, u, w)
    return g
