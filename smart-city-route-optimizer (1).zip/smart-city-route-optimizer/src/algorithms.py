"""Dijkstra (binary heap) and Bellman-Ford shortest path algorithms."""
import heapq

INF = float("inf")


def reconstruct_path(prev, source, target):
    if target not in prev and target != source:
        return None
    path, node = [], target
    while node is not None:
        path.append(node)
        node = prev.get(node)
    path.reverse()
    return path if path[0] == source else None


def dijkstra(graph, source):
    """O((V + E) log V). Requires non-negative weights."""
    dist = {v: INF for v in graph.vertices}
    prev = {source: None}
    dist[source] = 0
    heap = [(0, source)]
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue
        for v, w in graph.adj[u]:
            if w < 0:
                raise ValueError("Dijkstra does not support negative weights")
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, v))
    return dist, prev


def bellman_ford(graph, source):
    """O(V * E). Supports negative weights and detects negative cycles."""
    dist = {v: INF for v in graph.vertices}
    prev = {source: None}
    dist[source] = 0
    edges = list(graph.edges())
    for _ in range(graph.num_vertices - 1):
        updated = False
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                prev[v] = u
                updated = True
        if not updated:      # early exit optimisation
            break
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            raise ValueError("Graph contains a negative-weight cycle")
    return dist, prev
