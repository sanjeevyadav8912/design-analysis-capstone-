# Smart City Route Optimization System

Finds the shortest / most efficient route between locations in a city.
Locations are **vertices**, roads are **weighted edges** (weight = travel time in minutes).
Implements **Dijkstra's** and **Bellman-Ford** algorithms and compares their runtime across graph sizes.

## Project structure
```
src/graph.py        CityGraph class + random city generator
src/algorithms.py   dijkstra(), bellman_ford(), reconstruct_path()
src/main.py         CLI demo on a small named city
src/benchmark.py    Runtime comparison -> results/benchmark.csv + .png
tests/              Unit tests (pytest)
```

## Setup & run
```bash
pip install -r requirements.txt
python src/main.py --source Airport --target Stadium --algo dijkstra
python src/main.py --source Market --target Airport --algo bellman-ford
python src/benchmark.py
pytest
```

Example output:
```
Algorithm : dijkstra
Route     : Airport -> Central Station -> University -> Hospital -> Stadium
Total cost: 38 min
```

## Algorithms
| | Dijkstra (binary heap) | Bellman-Ford |
|---|---|---|
| Time complexity | O((V + E) log V) | O(V · E) |
| Negative weights | No | Yes |
| Negative cycle detection | No | Yes |
| Best for | Road networks (non-negative weights) | Graphs with penalties/discounts, cycle checks |

## Performance comparison
Random connected graphs (about 8 edges per vertex), best of 3 runs, single source:

| Vertices | Edges | Dijkstra (ms) | Bellman-Ford (ms) |
|---|---|---|---|
| 50 | 388 | 0.054 | 0.158 |
| 100 | 790 | 0.079 | 0.299 |
| 200 | 1592 | 0.159 | 0.665 |
| 400 | 3186 | 0.404 | 2.024 |
| 800 | 6390 | 0.884 | 5.018 |
| 1600 | 12792 | 2.695 | 11.645 |

(Timings vary by machine; re-run `python src/benchmark.py` for your own numbers.
A plot is saved to `results/benchmark.png`.)

## Conclusion
Dijkstra is consistently faster (roughly 3-6x here) and is the right choice for city road
networks where travel times are never negative. Bellman-Ford is slower, but handles
negative weights and detects negative cycles. Bellman-Ford's early-exit optimisation
makes it faster than its worst case on these graphs, since distances settle in few passes.
Both algorithms returned identical distances on all tested random graphs.

## Possible extensions
Add A* search, load real road data (OpenStreetMap), visualise routes with networkx, support live traffic weights.
